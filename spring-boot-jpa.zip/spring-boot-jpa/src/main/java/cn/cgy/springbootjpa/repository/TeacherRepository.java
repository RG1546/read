package cn.cgy.springbootjpa.repository;

import cn.cgy.springbootjpa.entity.NewTeacher;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

/**
 * repository 资源库，数据库
 * 构建用于数据操作的类，它是直接操作数据库的，注意它是个接口。用它的对象就可以实现数据库的操作。
 * 最底层，直接与数据库交接
 * interface 接口，直接在这里就继承了JapRespority
 */
public interface TeacherRepository extends JpaRepository <NewTeacher,String>{
    //


    List<NewTeacher> findByName(String name);
    List<NewTeacher> findByNameLike(String name);
    List<NewTeacher> findByIdIn(Collection<String> name);
}
