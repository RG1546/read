package cn.cgy.springbootjpa.controller;

import cn.cgy.springbootjpa.entity.NewTeacher;
import cn.cgy.springbootjpa.service.NewTeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
public class HelloTeacher {

    @Resource
    private NewTeacherService newTeacherService;

    @ResponseBody
    @GetMapping("/cgy")

    private List<NewTeacher> newTeacherList(){
        return newTeacherService.findAll();
    }

}

