package com.example.wechat_reading;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Book_Share extends AppCompatActivity implements View.OnClickListener {
    MyHelper myHelper;
    private Button Bt_share;
    private Button Bt_delete;
    private Button Bt_alter;
    private Button Bt_query;
    private TextView Tv_show;
    private EditText Et_Name;
    private EditText Et_Feeling;
    private Bundle savedInstanceState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book__share);
        init();//初始化控件
        myHelper = new MyHelper(this);
    }

    private void init() {
        Bt_share = (Button)findViewById(R.id.bt_share);
        Bt_query = (Button)findViewById(R.id.bt_query);
        Bt_alter = (Button)findViewById(R.id.bt_alter);
        Bt_delete = (Button)findViewById(R.id.bt_delete);
        Tv_show = (TextView)findViewById(R.id.tv_show);
        Et_Name = (EditText)findViewById(R.id.et_bookname);
        Et_Feeling = (EditText)findViewById(R.id.et_feeling);
        Bt_share.setOnClickListener(this);
        Bt_query.setOnClickListener(this);
        Bt_alter.setOnClickListener(this);
        Bt_delete.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String name;
        String feeling;
        SQLiteDatabase db;
        ContentValues values;
        switch(v.getId()){
            case R.id.bt_share://添加，发表数据
                //先从et那里得到数据
                name = Et_Name.getText().toString();
                feeling = Et_Feeling.getText().toString();
                db = myHelper.getWritableDatabase();//获取可读SQLiteDatabase对象
                values = new ContentValues();//创建ContentValues对象
                //放入得到的数据
                //Sfeeling，Bname是列名
                values.put("Bname", name);
                values.put("Sfeeling", feeling);
                //插入数据
                db.insert("share",null,values);
                //Toast用于向用户显示一些帮助/提示
                Toast.makeText(this,"信息已添加",Toast.LENGTH_SHORT).show();
                db.close();
                break;
            case R.id.bt_query://查询数据
                db = myHelper.getReadableDatabase();
                //Cursor 是每行的集合。使用 moveToFirst() 定位第一行。
                Cursor cursor = db.query("share",null,null,null,null,null,null);
                if(cursor.getCount()==0){//总数据项数
                    Tv_show.setText("");
                    Toast.makeText(this,"没有数据",Toast.LENGTH_SHORT).show();
                }
                else{
                    cursor.moveToFirst();
                    //是设置文本信息的。该方法有2中参数， 一种直接传入参数时字符串，一种传输参数是整型：
                    Tv_show.setText("BookName：" + cursor.getString(1) + "\n" + "ShareFeeling：" + cursor.getString(2));
                }
                while(cursor.moveToNext()){
                // append()在以前的内容后面添加
                    Tv_show.append("\n" + "BookName：" + cursor.getString(1) +"\n" + "ShareFeeling：" + cursor.getString(2));
                }
                cursor.close();//关闭游标，释放资源
                db.close();
                break;

            case R.id.bt_alter://修改数据
                db = myHelper.getWritableDatabase();
                values = new ContentValues();
                values.put("Sfeeling", feeling = Et_Feeling.getText().toString());
                db.update("share",values,"Bname = ?",new String[]{Et_Name.getText().toString()});
                Toast.makeText(this,"信息已被修改",Toast.LENGTH_SHORT).show();
                db.close();
                break;

            case R.id.bt_delete://删除数据
                db = myHelper.getWritableDatabase();
                db.delete("share","Bname = ?",new String[]{Et_Name.getText().toString()});
                //db.delete("share","Bname = ",null);
                Toast.makeText(this,"信息已被删除",Toast.LENGTH_SHORT).show();
                Tv_show.setText("");
                db.close();
                break;
        }
    }

    class MyHelper extends SQLiteOpenHelper {
        public MyHelper(Context context) {
            super(context, "yuedu.db", null, 1);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            //初始化数据库表结构，执行一条建表的sql语句
            db.execSQL("create table share(_id integer primary key autoincrement ,Bname varchar(20) ,Sfeeling varchar(100))");
            Log.d("", "数据库创建了");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.d("", "数据库升级了");
        }
    }
}
