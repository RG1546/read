package cn.cgy.springbootjpa.service;

import cn.cgy.springbootjpa.entity.NewTeacher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;
import java.util.List;

/**
 * 服务层，给予用户使用的接口，不可以直接把TeacherRepository给予用户使用，
 */

public interface NewTeacherService {
    NewTeacher findById(String id);
    List<NewTeacher> findAll();
    NewTeacher save(NewTeacher newTeacher);
    void delete(String id);

    Page<NewTeacher> findAll(Pageable pageable);
    List<NewTeacher> findByName(String name);
    List<NewTeacher> findByNameLike(String name);
    List<NewTeacher> findByIdIn(Collection<String> ids);
}
